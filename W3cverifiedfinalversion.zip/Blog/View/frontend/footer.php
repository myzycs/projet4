	<!-- Le pied de page -->
	<br><br><br>
	<nav class="navbar navbar-expand-sm justify-content-center fixed-bottom">Retrouvez le sur les reseaux sociaux : 
		<a class="icone" href="#"><img src="public/images/facebook-icon.png" alt="facebook icone"></a>
		<a class="icone" href=""><img src="public/images/twitter-icon.png" alt="twitter icone"></a>
		<a class="icone" href=""><img src="public/images/instagram-icon.png" alt="instagram icone"></a>
	</nav>
	