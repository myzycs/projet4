<!-- L'en-tête -->
	<header>
		<h1>BILLET SIMPLE POUR L'ALASKA</h1>
		<h2>JEAN FORTEROCHE</h2>
	</header>